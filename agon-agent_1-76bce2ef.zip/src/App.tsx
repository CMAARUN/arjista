import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Navigation from './components/Navigation';
import NotificationTicker from './components/NotificationTicker';
import Hero from './components/Hero';
import Services from './components/Services';
import TaxCalculator from './components/TaxCalculator';
import Team from './components/Team';
import Partner from './components/Partner';
import Blog from './components/Blog';
import Contact from './components/Contact';
import Footer from './components/Footer';
import WhatsAppButton from './components/WhatsAppButton';
import Admin from './components/Admin';

function HomePage() {
  return (
    <div className="min-h-screen bg-[#0B1B32]">
      <Navigation />
      <NotificationTicker />
      <main>
        <Hero />
        <Services />
        <TaxCalculator />
        <Team />
        <Partner />
        <Blog />
        <Contact />
      </main>
      <Footer />
      <WhatsAppButton />
    </div>
  );
}

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/admin" element={<Admin />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;