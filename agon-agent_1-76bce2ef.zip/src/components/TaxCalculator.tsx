import { useState } from 'react';
import { motion } from 'framer-motion';
import { Calculator, IndianRupee, TrendingUp, AlertCircle, Info, Receipt } from 'lucide-react';

const oldTaxSlabs = [
  { min: 0, max: 250000, rate: 0 },
  { min: 250000, max: 500000, rate: 5 },
  { min: 500000, max: 1000000, rate: 20 },
  { min: 1000000, max: Infinity, rate: 30 },
];

const newTaxSlabs = [
  { min: 0, max: 400000, rate: 0 },
  { min: 400000, max: 800000, rate: 5 },
  { min: 800000, max: 1200000, rate: 10 },
  { min: 1200000, max: 1600000, rate: 15 },
  { min: 1600000, max: 2000000, rate: 20 },
  { min: 2000000, max: 2400000, rate: 25 },
  { min: 2400000, max: Infinity, rate: 30 },
];

const STANDARD_DEDUCTION_NEW = 75000;
const STANDARD_DEDUCTION_OLD = 50000;
const REBATE_LIMIT_NEW = 1200000;

export default function TaxCalculator() {
  const [income, setIncome] = useState<string>('');
  const [deductions, setDeductions] = useState<string>('');
  const [regime, setRegime] = useState<'old' | 'new'>('new');
  const [result, setResult] = useState<{
    grossIncome: number;
    standardDeduction: number;
    otherDeductions: number;
    taxableIncome: number;
    baseTax: number;
    rebate87A: number;
    taxAfterRebate: number;
    cess: number;
    totalTax: number;
    effectiveRate: number;
  } | null>(null);

  const calculateTax = (taxableIncome: number, slabs: typeof newTaxSlabs) => {
    let tax = 0;
    for (const slab of slabs) {
      if (taxableIncome > slab.min) {
        const taxableInSlab = Math.min(taxableIncome, slab.max) - slab.min;
        tax += (taxableInSlab * slab.rate) / 100;
      }
    }
    return tax;
  };

  const handleCalculate = () => {
    const grossIncome = parseFloat(income) || 0;
    const otherDeductions = parseFloat(deductions) || 0;
    const standardDeduction = regime === 'new' ? STANDARD_DEDUCTION_NEW : STANDARD_DEDUCTION_OLD;
    const taxableIncome = Math.max(0, grossIncome - standardDeduction - (regime === 'old' ? otherDeductions : 0));

    const slabs = regime === 'new' ? newTaxSlabs : oldTaxSlabs;
    let baseTax = calculateTax(taxableIncome, slabs);
    
    let rebate87A = 0;
    if (regime === 'new' && taxableIncome <= REBATE_LIMIT_NEW) {
      rebate87A = baseTax;
    }
    
    const taxAfterRebate = Math.max(0, baseTax - rebate87A);
    const cess = taxAfterRebate * 0.04;
    const totalTax = taxAfterRebate + cess;
    const effectiveRate = grossIncome > 0 ? (totalTax / grossIncome) * 100 : 0;

    setResult({
      grossIncome,
      standardDeduction,
      otherDeductions: regime === 'old' ? otherDeductions : 0,
      taxableIncome,
      baseTax,
      rebate87A,
      taxAfterRebate,
      cess,
      totalTax,
      effectiveRate,
    });
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0,
    }).format(amount);
  };

  return (
    <section id="calculator" className="relative py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <div className="inline-flex items-center gap-2 bg-blue-100 border border-blue-200 rounded-full px-4 py-2 mb-4">
            <Receipt className="w-4 h-4 text-blue-600" />
            <span className="text-blue-700 text-sm font-medium">FY 2025-26 (AY 2026-27)</span>
          </div>
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Income Tax <span className="text-blue-600">Calculator</span>
          </h2>
          <p className="text-gray-600 max-w-2xl mx-auto text-lg">
            Calculate your tax liability as per Income Tax Act 2025. Compare both tax regimes and optimize your tax planning.
          </p>
        </motion.div>

        <div className="max-w-5xl mx-auto">
          <div className="bg-gray-50 border border-gray-200 rounded-2xl p-8 shadow-lg">
            <div className="grid md:grid-cols-2 gap-8">
              {/* Input Section */}
              <div className="space-y-6">
                <div>
                  <label className="block text-gray-700 text-sm font-medium mb-2">Tax Regime</label>
                  <div className="flex gap-4">
                    <button
                      onClick={() => setRegime('new')}
                      className={`flex-1 py-3 px-4 rounded-lg font-semibold transition-all ${
                        regime === 'new'
                          ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/30'
                          : 'bg-white border border-gray-300 text-gray-600 hover:border-blue-300'
                      }`}
                    >
                      New Regime
                    </button>
                    <button
                      onClick={() => setRegime('old')}
                      className={`flex-1 py-3 px-4 rounded-lg font-semibold transition-all ${
                        regime === 'old'
                          ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/30'
                          : 'bg-white border border-gray-300 text-gray-600 hover:border-blue-300'
                      }`}
                    >
                      Old Regime
                    </button>
                  </div>
                </div>

                <div>
                  <label className="block text-gray-700 text-sm font-medium mb-2">Annual Gross Income</label>
                  <div className="relative">
                    <IndianRupee className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-blue-600" />
                    <input
                      type="number"
                      value={income}
                      onChange={(e) => setIncome(e.target.value)}
                      placeholder="Enter your income"
                      className="w-full bg-white border border-gray-300 rounded-lg py-3 pl-12 pr-4 text-gray-900 placeholder-gray-400 focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 transition-all"
                    />
                  </div>
                </div>

                {regime === 'old' && (
                  <div>
                    <label className="block text-gray-700 text-sm font-medium mb-2">Deductions (80C, 80D, HRA, etc.)</label>
                    <div className="relative">
                      <IndianRupee className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-blue-600" />
                      <input
                        type="number"
                        value={deductions}
                        onChange={(e) => setDeductions(e.target.value)}
                        placeholder="Enter deductions"
                        className="w-full bg-white border border-gray-300 rounded-lg py-3 pl-12 pr-4 text-gray-900 placeholder-gray-400 focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 transition-all"
                      />
                    </div>
                    <p className="text-gray-500 text-xs mt-1">Max 80C: ₹1,50,000 | 80D: ₹25,000-₹1,00,000</p>
                  </div>
                )}

                {regime === 'new' && (
                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                    <div className="flex items-start gap-2">
                      <Info className="w-4 h-4 text-blue-600 mt-0.5 flex-shrink-0" />
                      <p className="text-gray-700 text-sm">
                        New regime has <span className="font-semibold text-blue-700">₹75,000 standard deduction</span> auto-applied. 
                        Most deductions (80C, 80D, HRA) are not available.
                      </p>
                    </div>
                  </div>
                )}

                <button
                  onClick={handleCalculate}
                  className="w-full bg-blue-600 hover:bg-blue-700 text-white py-4 rounded-lg font-semibold text-lg transition-all shadow-lg hover:shadow-blue-600/30 flex items-center justify-center gap-2"
                >
                  <Calculator className="w-5 h-5" />
                  Calculate Tax
                </button>
              </div>

              {/* Results Section */}
              <div className="bg-white rounded-xl p-6 border border-gray-200">
                <h3 className="text-gray-900 font-semibold mb-6 flex items-center gap-2">
                  <TrendingUp className="w-5 h-5 text-blue-600" />
                  Tax Computation (FY 2025-26)
                </h3>

                {result ? (
                  <div className="space-y-3">
                    <div className="flex justify-between py-2 border-b border-gray-100">
                      <span className="text-gray-600">Gross Income</span>
                      <span className="text-gray-900 font-medium">{formatCurrency(result.grossIncome)}</span>
                    </div>
                    <div className="flex justify-between py-2 border-b border-gray-100">
                      <span className="text-gray-600">Standard Deduction</span>
                      <span className="text-gray-500">(-) {formatCurrency(result.standardDeduction)}</span>
                    </div>
                    {result.otherDeductions > 0 && (
                      <div className="flex justify-between py-2 border-b border-gray-100">
                        <span className="text-gray-600">Other Deductions</span>
                        <span className="text-gray-500">(-) {formatCurrency(result.otherDeductions)}</span>
                      </div>
                    )}
                    <div className="flex justify-between py-2 border-b border-gray-100 bg-blue-50 px-2 rounded">
                      <span className="text-blue-700 font-medium">Taxable Income</span>
                      <span className="text-blue-700 font-medium">{formatCurrency(result.taxableIncome)}</span>
                    </div>
                    <div className="flex justify-between py-2 border-b border-gray-100">
                      <span className="text-gray-600">Tax on Total Income</span>
                      <span className="text-gray-900 font-medium">{formatCurrency(result.baseTax)}</span>
                    </div>
                    {result.rebate87A > 0 && (
                      <div className="flex justify-between py-2 border-b border-gray-100 text-green-600">
                        <span>87A Rebate (Income ≤ ₹12L)</span>
                        <span>(-) {formatCurrency(result.rebate87A)}</span>
                      </div>
                    )}
                    <div className="flex justify-between py-2 border-b border-gray-100">
                      <span className="text-gray-600">Health & Education Cess (4%)</span>
                      <span className="text-gray-900 font-medium">{formatCurrency(result.cess)}</span>
                    </div>
                    <div className="flex justify-between py-4 bg-blue-600 rounded-lg px-4 mt-2">
                      <span className="text-white font-bold">Total Tax Liability</span>
                      <span className="text-white font-bold text-xl">{formatCurrency(result.totalTax)}</span>
                    </div>
                    <div className="flex justify-between py-2">
                      <span className="text-gray-600">Effective Tax Rate</span>
                      <span className="text-blue-600 font-medium">{result.effectiveRate.toFixed(2)}%</span>
                    </div>
                    {result.totalTax === 0 && result.taxableIncome > 0 && regime === 'new' && (
                      <div className="bg-green-50 border border-green-200 rounded-lg p-3 mt-2">
                        <p className="text-green-700 text-sm text-center font-medium">
                          ✓ Zero Tax! Income up to ₹12 Lakhs is tax-free under New Regime (87A Rebate)
                        </p>
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="flex flex-col items-center justify-center h-48 text-gray-400">
                    <AlertCircle className="w-12 h-12 mb-4 opacity-50" />
                    <p>Enter your income and click Calculate</p>
                  </div>
                )}
              </div>
            </div>

            {/* Tax Slabs Reference */}
            <div className="mt-8 grid md:grid-cols-2 gap-6">
              <div className="bg-white rounded-xl p-4 border border-gray-200">
                <h4 className="text-blue-700 font-semibold mb-3 text-sm">New Regime Slabs (FY 2025-26)</h4>
                <div className="space-y-1 text-xs">
                  <div className="flex justify-between text-gray-600"><span>₹0 - ₹4,00,000</span><span className="text-gray-900 font-medium">0%</span></div>
                  <div className="flex justify-between text-gray-600"><span>₹4,00,001 - ₹8,00,000</span><span className="text-gray-900 font-medium">5%</span></div>
                  <div className="flex justify-between text-gray-600"><span>₹8,00,001 - ₹12,00,000</span><span className="text-gray-900 font-medium">10%</span></div>
                  <div className="flex justify-between text-gray-600"><span>₹12,00,001 - ₹16,00,000</span><span className="text-gray-900 font-medium">15%</span></div>
                  <div className="flex justify-between text-gray-600"><span>₹16,00,001 - ₹20,00,000</span><span className="text-gray-900 font-medium">20%</span></div>
                  <div className="flex justify-between text-gray-600"><span>₹20,00,001 - ₹24,00,000</span><span className="text-gray-900 font-medium">25%</span></div>
                  <div className="flex justify-between text-gray-600"><span>Above ₹24,00,000</span><span className="text-gray-900 font-medium">30%</span></div>
                </div>
              </div>
              <div className="bg-white rounded-xl p-4 border border-gray-200">
                <h4 className="text-blue-700 font-semibold mb-3 text-sm">Old Regime Slabs (FY 2025-26)</h4>
                <div className="space-y-1 text-xs">
                  <div className="flex justify-between text-gray-600"><span>₹0 - ₹2,50,000</span><span className="text-gray-900 font-medium">0%</span></div>
                  <div className="flex justify-between text-gray-600"><span>₹2,50,001 - ₹5,00,000</span><span className="text-gray-900 font-medium">5%</span></div>
                  <div className="flex justify-between text-gray-600"><span>₹5,00,001 - ₹10,00,000</span><span className="text-gray-900 font-medium">20%</span></div>
                  <div className="flex justify-between text-gray-600"><span>Above ₹10,00,000</span><span className="text-gray-900 font-medium">30%</span></div>
                </div>
                <p className="text-gray-500 text-xs mt-3">+ Deductions under 80C, 80D, HRA, LTA etc.</p>
              </div>
            </div>

            <p className="text-gray-500 text-xs mt-6 text-center">
              * Calculator as per Income Tax Act 2025. For detailed tax planning, contact CMA Arun Bishnoi.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}