import { Linkedin, Twitter, Mail, ArrowRight, Facebook, Instagram, Youtube } from 'lucide-react';

const quickLinks = [
  { name: 'Home', href: '#home' },
  { name: 'Services', href: '#services' },
  { name: 'Tax Calculator', href: '#calculator' },
  { name: 'Team', href: '#team' },
  { name: 'Partner', href: '#partner' },
  { name: 'Insights', href: '#blog' },
  { name: 'Contact', href: '#contact' },
];

const services = [
  'Statutory Audits',
  'Tax Compliance',
  'Virtual CFO',
  'GST Advisory',
  'Startup India',
  'Wealth Management',
];

const socialLinks = [
  { name: 'LinkedIn', icon: Linkedin, href: 'https://www.linkedin.com/company/arjista-services', color: 'hover:bg-[#0077B5]' },
  { name: 'Facebook', icon: Facebook, href: 'https://www.facebook.com/arjistaservices', color: 'hover:bg-[#1877F2]' },
  { name: 'Instagram', icon: Instagram, href: 'https://www.instagram.com/arjistaservices', color: 'hover:bg-[#E4405F]' },
  { name: 'Twitter', icon: Twitter, href: 'https://twitter.com/arjistaservices', color: 'hover:bg-[#1DA1F2]' },
  { name: 'YouTube', icon: Youtube, href: 'https://www.youtube.com/@arjistaservices', color: 'hover:bg-[#FF0000]' },
];

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="relative bg-gray-950 overflow-hidden">
      {/* Top Border */}
      <div className="h-px bg-gradient-to-r from-transparent via-blue-500/30 to-transparent" />
      
      {/* Main Footer Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-12">
          {/* Brand */}
          <div className="lg:col-span-1">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-12 h-12 bg-gradient-to-br from-blue-600 to-blue-800 rounded-xl flex items-center justify-center shadow-lg shadow-blue-500/20">
                <span className="text-white font-bold text-2xl">A</span>
              </div>
              <div>
                <span className="text-white font-bold text-xl tracking-wide">ARJISTA</span>
                <span className="block text-blue-400 text-xs tracking-[0.2em] uppercase">Services & Projects</span>
              </div>
            </div>
            <p className="text-gray-400 text-sm mb-6 leading-relaxed">
              Strategic Intelligence. Absolute Compliance. Your trusted partner for professional 
              assurance, taxation, and advisory services.
            </p>
            
            {/* Social Media Links */}
            <div className="flex gap-2">
              {socialLinks.map((social) => (
                <a
                  key={social.name}
                  href={social.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className={`w-10 h-10 bg-gray-800 border border-gray-700 rounded-lg flex items-center justify-center transition-all ${social.color} hover:border-transparent`}
                  aria-label={social.name}
                >
                  <social.icon className="w-5 h-5 text-gray-400 hover:text-white" />
                </a>
              ))}
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-white font-semibold mb-6 text-sm uppercase tracking-wider">Quick Links</h4>
            <ul className="space-y-3">
              {quickLinks.map((link) => (
                <li key={link.name}>
                  <a
                    href={link.href}
                    className="text-gray-400 hover:text-blue-400 transition-colors text-sm flex items-center gap-2 group"
                  >
                    <ArrowRight className="w-3 h-3 opacity-0 -ml-4 group-hover:opacity-100 group-hover:ml-0 transition-all" />
                    {link.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Services */}
          <div>
            <h4 className="text-white font-semibold mb-6 text-sm uppercase tracking-wider">Our Services</h4>
            <ul className="space-y-3">
              {services.map((service) => (
                <li key={service}>
                  <a
                    href="#services"
                    className="text-gray-400 hover:text-blue-400 transition-colors text-sm flex items-center gap-2 group"
                  >
                    <ArrowRight className="w-3 h-3 opacity-0 -ml-4 group-hover:opacity-100 group-hover:ml-0 transition-all" />
                    {service}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-white font-semibold mb-6 text-sm uppercase tracking-wider">Contact Us</h4>
            <div className="space-y-4 text-sm">
              <div>
                <p className="text-blue-400 text-xs uppercase tracking-wider mb-1">Address</p>
                <p className="text-gray-400 leading-relaxed">
                  TF-9/330, Gali No. 9, Lalita Park, Laxmi Nagar, Delhi-110092
                </p>
              </div>
              <div>
                <p className="text-blue-400 text-xs uppercase tracking-wider mb-1">Telephone</p>
                <div className="space-y-1">
                  <a href="tel:+919817178929" className="text-gray-400 hover:text-blue-400 transition-colors block">
                    +91 98171 78929
                  </a>
                  <a href="tel:+918708971502" className="text-gray-400 hover:text-blue-400 transition-colors block">
                    +91 87089 71502
                  </a>
                </div>
              </div>
              <div>
                <p className="text-blue-400 text-xs uppercase tracking-wider mb-1">Email</p>
                <a href="mailto:cmafirmarun@gmail.com" className="text-gray-400 hover:text-blue-400 transition-colors">
                  cmafirmarun@gmail.com
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="text-center md:text-left">
              <p className="text-gray-500 text-sm">
                © {currentYear} Arjista Services & Projects. All rights reserved.
              </p>
              <p className="text-gray-600 text-xs mt-1">
                Founded by <span className="text-blue-400">CMA Arun Bishnoi</span>
              </p>
            </div>
            <div className="flex gap-6 text-sm">
              <a href="#" className="text-gray-500 hover:text-blue-400 transition-colors">
                Privacy Policy
              </a>
              <a href="#" className="text-gray-500 hover:text-blue-400 transition-colors">
                Terms of Engagement
              </a>
              <a href="/admin" className="text-gray-500 hover:text-blue-400 transition-colors">
                Admin
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}