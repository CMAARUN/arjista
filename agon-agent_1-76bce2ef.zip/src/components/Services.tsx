import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  FileCheck, PieChart, Landmark, Shield, FileText, Rocket,
  Wallet, BookOpen, ArrowRight, CheckCircle, Sparkles, X, AlertTriangle, Clock, TrendingUp
} from 'lucide-react';

const services = [
  {
    icon: FileCheck,
    title: 'Statutory & Internal Audits',
    desc: 'Independent assurance on financial statements ensuring regulatory compliance and stakeholder confidence.',
    image: '/images/service-audit.jpg',
    color: 'from-emerald-600 to-teal-700',
    textColor: 'text-emerald-400',
    bgColor: 'bg-emerald-500/20',
    borderColor: 'border-emerald-500/30',
    category: 'AUDIT & ASSURANCE',
    problems: [
      'Regulatory penalties up to ₹5 lakh for non-compliance with audit requirements',
      'Stakeholders losing confidence due to unaudited financial statements',
      'Detection of frauds and irregularities at late stages causing huge losses',
      'Inability to raise funds from banks and investors without proper audit',
      'Legal complications in mergers, acquisitions due to audit gaps',
    ],
    whyUrgent: 'Non-compliance with audit requirements can lead to heavy penalties, legal actions, and loss of business credibility. Early detection of issues saves crores in potential losses.',
    benefits: ['Regulatory compliance', 'Fraud detection', 'Investor confidence', 'Risk mitigation', 'Better governance'],
  },
  {
    icon: PieChart,
    title: 'Virtual CFO Services',
    desc: 'Strategic financial leadership, MIS reporting, cash flow management for growing businesses.',
    image: '/images/service-cfo.jpg',
    color: 'from-violet-600 to-purple-700',
    textColor: 'text-violet-400',
    bgColor: 'bg-violet-500/20',
    borderColor: 'border-violet-500/30',
    category: 'ADVISORY',
    problems: [
      'Cash flow crises hitting businesses unexpectedly due to poor planning',
      'No proper MIS leading to uninformed business decisions',
      'Missing growth opportunities due to lack of financial strategy',
      'Working capital mismanagement causing operational disruptions',
      'No financial visibility for board and stakeholders',
    ],
    whyUrgent: 'Without proper financial oversight, businesses face cash crunches, miss growth opportunities, and make decisions based on incomplete information. A Virtual CFO provides expert guidance at a fraction of full-time cost.',
    benefits: ['Strategic guidance', 'Cash flow control', 'Better decisions', 'Cost savings', 'Growth planning'],
  },
  {
    icon: Landmark,
    title: 'Direct & Indirect Tax',
    desc: 'Comprehensive Income Tax and GST compliance, planning, and advisory for optimal tax efficiency.',
    image: '/images/service-tax.jpg',
    color: 'from-blue-600 to-indigo-700',
    textColor: 'text-blue-400',
    bgColor: 'bg-blue-500/20',
    borderColor: 'border-blue-500/30',
    category: 'TAXATION',
    problems: [
      'Tax notices and scrutiny due to incorrect filings and calculations',
      'Paying excess tax due to lack of proper planning and deductions',
      'GST input credit blocked due to compliance gaps',
      'Interest and penalties mounting on delayed tax payments',
      'Litigation risks from aggressive tax positions without expert guidance',
    ],
    whyUrgent: 'Tax non-compliance attracts heavy penalties, interest, and legal proceedings. Many businesses overpay taxes due to poor planning. Expert guidance ensures compliance while optimizing tax outflow.',
    benefits: ['Tax optimization', 'Compliance assurance', 'Penalty avoidance', 'Input credit recovery', 'Risk reduction'],
  },
  {
    icon: Shield,
    title: 'Litigation & Appeals',
    desc: 'Expert representation before tax authorities, CIT(A), ITAT, and appellate tribunals.',
    image: '/images/service-litigation.jpg',
    color: 'from-rose-600 to-red-700',
    textColor: 'text-rose-400',
    bgColor: 'bg-rose-500/20',
    borderColor: 'border-rose-500/30',
    category: 'DEFENSE',
    problems: [
      'Tax demands running into crores due to unfavorable assessments',
      'Lost appeals due to improper documentation and weak arguments',
      'Time-barred appeals causing irreversible tax liabilities',
      'Harassment from tax authorities during surveys and searches',
      'Blocked refunds due to pending litigation matters',
    ],
    whyUrgent: 'Unaddressed tax disputes can escalate into massive liabilities. Missing appeal deadlines means losing legal rights forever. Expert representation at early stages saves crores and prevents escalation.',
    benefits: ['Strong defense', 'Deadline compliance', 'Liability reduction', 'Refund recovery', 'Peace of mind'],
  },
  {
    icon: FileText,
    title: 'MCA/ROC Compliance',
    desc: 'End-to-end company law compliance including annual filings, event-based compliances.',
    image: '/images/service-mca.jpg',
    color: 'from-amber-600 to-orange-700',
    textColor: 'text-amber-400',
    bgColor: 'bg-amber-500/20',
    borderColor: 'border-amber-500/30',
    category: 'COMPLIANCE',
    problems: [
      'Company strike-off due to non-filing of annual returns',
      'Directors disqualified for non-compliance with ROC requirements',
      'Heavy penalties of ₹100 per day for each default in filing',
      'Unable to obtain certificates for tenders, bank loans due to compliance gaps',
      'Legal complications in share transfers, director changes without proper filings',
    ],
    whyUrgent: 'Non-compliance with MCA requirements leads to company strike-off, director disqualification, and inability to conduct business. Penalties compound daily. Immediate action prevents business disruption.',
    benefits: ['Company protection', 'Director safety', 'Tender eligibility', 'Loan approval', 'Legal compliance'],
  },
  {
    icon: Rocket,
    title: 'Startup India Advisory',
    desc: 'DPIIT recognition, tax exemptions, funding compliance, and growth advisory for startups.',
    image: '/images/service-startup.jpg',
    color: 'from-cyan-600 to-sky-700',
    textColor: 'text-cyan-400',
    bgColor: 'bg-cyan-500/20',
    borderColor: 'border-cyan-500/30',
    category: 'STARTUP',
    problems: [
      'Missing 80-IAC tax holiday benefit worth lakhs due to non-registration',
      'Angel tax issues blocking funding from investors',
      'ESOP compliance failures causing legal issues',
      'Unable to participate in government tenders reserved for startups',
      'Missing DPIIT benefits like fast-track patent filing, self-certification',
    ],
    whyUrgent: 'Startups lose significant tax benefits and funding opportunities without proper registration. Early compliance unlocks government incentives worth crores. Missing deadlines means losing benefits permanently.',
    benefits: ['Tax exemption', 'Funding ease', 'Government benefits', 'Patent support', 'Compliance ease'],
  },
  {
    icon: Wallet,
    title: 'HNI Wealth Management',
    desc: 'Strategic tax planning, investment structuring, and wealth optimization for HNIs.',
    image: '/images/service-wealth.jpg',
    color: 'from-[#C5A059] to-[#D4AF37]',
    textColor: 'text-[#C5A059]',
    bgColor: 'bg-[#C5A059]/20',
    borderColor: 'border-[#C5A059]/30',
    category: 'WEALTH',
    problems: [
      'Paying excessive tax due to inefficient investment structuring',
      'Wealth erosion due to poor estate and succession planning',
      'Legal complications in asset transfers to next generation',
      'Missing tax-efficient investment opportunities',
      'Risk of wealth exposure due to inadequate asset protection',
    ],
    whyUrgent: 'HNIs lose crores in taxes due to poor planning. Without proper structuring, wealth transfer becomes legally complex and tax-heavy. Early planning ensures wealth preservation and smooth succession.',
    benefits: ['Tax efficiency', 'Wealth preservation', 'Smooth succession', 'Asset protection', 'Growth optimization'],
  },
  {
    icon: BookOpen,
    title: 'Legal & Advisory Opinions',
    desc: 'Authoritative legal opinions on complex tax matters, transactions, and regulatory issues.',
    image: '/images/service-legal.jpg',
    color: 'from-pink-600 to-fuchsia-700',
    textColor: 'text-pink-400',
    bgColor: 'bg-pink-500/20',
    borderColor: 'border-pink-500/30',
    category: 'ADVISORY',
    problems: [
      'Entering transactions without understanding tax implications',
      'Regulatory actions due to non-compliance with changing laws',
      'Disputes with tax authorities due to unclear legal positions',
      'Business deals falling through due to unresolved legal issues',
      'Cross-border transactions facing regulatory hurdles',
    ],
    whyUrgent: 'Complex transactions without proper legal opinion can lead to massive tax liabilities and legal disputes. Expert opinion before transactions prevents costly mistakes and provides legal protection.',
    benefits: ['Risk prevention', 'Legal clarity', 'Transaction safety', 'Dispute avoidance', 'Regulatory compliance'],
  },
];

const whyDifferent = [
  { title: 'CMA Qualified Expertise', desc: 'Specialized cost and management accounting knowledge.' },
  { title: 'Big Four Experience', desc: 'Professional standards from leading global firms.' },
  { title: 'Technology-Driven', desc: 'Modern tools for efficiency and accuracy.' },
  { title: 'Personalized Attention', desc: 'Direct partner involvement in every engagement.' },
];

const approach = [
  { step: '01', title: 'Understand', desc: 'Deep dive into your business' },
  { step: '02', title: 'Analyze', desc: 'Review compliance position' },
  { step: '03', title: 'Strategize', desc: 'Custom solutions aligned' },
  { step: '04', title: 'Execute', desc: 'Flawless implementation' },
];

export default function Services() {
  const [selectedService, setSelectedService] = useState<typeof services[0] | null>(null);

  return (
    <section id="services" className="relative py-24 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-[#0B1B32] via-[#0f2239] to-[#0B1B32]" />
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,rgba(197,160,89,0.08),transparent_60%)]" />
      <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-[#C5A059]/30 to-transparent" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <motion.div
            initial={{ scale: 0 }}
            whileInView={{ scale: 1 }}
            viewport={{ once: true }}
            className="inline-flex items-center gap-2 bg-gradient-to-r from-[#C5A059]/20 to-[#D4AF37]/10 border border-[#C5A059]/30 rounded-full px-5 py-2 mb-6"
          >
            <Sparkles className="w-4 h-4 text-[#C5A059]" />
            <span className="text-[#C5A059] text-sm font-semibold tracking-wide">Professional Excellence</span>
          </motion.div>
          
          <h2 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-white mb-6">
            Our <span className="bg-gradient-to-r from-[#C5A059] via-[#D4AF37] to-[#C5A059] bg-clip-text text-transparent">Professional</span> Services
          </h2>
          
          <p className="text-white/60 max-w-3xl mx-auto text-lg leading-relaxed">
            Comprehensive solutions tailored to your unique business needs. From statutory compliance to strategic advisory, 
            we deliver excellence at every step.
          </p>
        </motion.div>

        {/* Services Grid */}
        <div className="grid md:grid-cols-2 gap-6 mb-20">
          {services.map((service, index) => (
            <motion.div
              key={service.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.08 }}
              className="group relative"
            >
              <div className="relative h-72 rounded-2xl overflow-hidden border border-white/10 hover:border-white/30 transition-all duration-500">
                <img
                  src={service.image}
                  alt={service.title}
                  className="absolute inset-0 w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                />
                <div className={`absolute inset-0 bg-gradient-to-br ${service.color} opacity-85 group-hover:opacity-75 transition-opacity duration-500`} />
                <div className="absolute inset-0 bg-[#0B1B32]/40" />
                
                <div className="relative h-full p-8 flex flex-col justify-between">
                  <div>
                    <div className={`inline-flex items-center gap-2 ${service.bgColor} ${service.borderColor} border rounded-full px-3 py-1 mb-4`}>
                      <span className={`${service.textColor} text-xs font-bold tracking-wider`}>{service.category}</span>
                    </div>
                    <div className={`w-14 h-14 ${service.bgColor} backdrop-blur-sm rounded-xl flex items-center justify-center mb-4 border ${service.borderColor} group-hover:scale-110 transition-transform duration-300`}>
                      <service.icon className={`w-7 h-7 ${service.textColor}`} />
                    </div>
                  </div>
                  
                  <div>
                    <h3 className="text-2xl font-bold text-white mb-3 group-hover:translate-x-2 transition-transform duration-300">
                      {service.title}
                    </h3>
                    <p className="text-white/80 text-sm leading-relaxed mb-4 line-clamp-2">
                      {service.desc}
                    </p>
                    <button
                      onClick={() => setSelectedService(service)}
                      className={`flex items-center gap-2 ${service.textColor} font-semibold text-sm group-hover:gap-3 transition-all`}
                    >
                      <span>Learn More</span>
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* What Makes Us Different */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mb-20"
        >
          <div className="text-center mb-12">
            <h3 className="text-3xl font-bold text-white mb-4">
              What Makes Us <span className="text-[#C5A059]">Different</span>?
            </h3>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {whyDifferent.map((item, index) => (
              <motion.div
                key={item.title}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="bg-gradient-to-br from-white/5 to-white/[0.02] border border-white/10 rounded-xl p-6 hover:border-[#C5A059]/30 transition-all group text-center"
              >
                <div className="w-12 h-12 bg-[#C5A059]/20 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-[#C5A059]/30 transition-colors">
                  <CheckCircle className="w-6 h-6 text-[#C5A059]" />
                </div>
                <h4 className="text-white font-semibold mb-2">{item.title}</h4>
                <p className="text-white/50 text-sm">{item.desc}</p>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Our Approach */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="relative mb-16"
        >
          <div className="text-center mb-12">
            <h3 className="text-3xl font-bold text-white mb-4">
              How We <span className="text-[#C5A059]">Approach</span>
            </h3>
          </div>

          <div className="relative">
            <div className="hidden lg:block absolute top-1/2 left-0 right-0 h-0.5 bg-gradient-to-r from-transparent via-[#C5A059]/30 to-transparent -translate-y-1/2" />
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
              {approach.map((item, index) => (
                <motion.div
                  key={item.step}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.15 }}
                  className="relative text-center"
                >
                  <div className="relative inline-flex items-center justify-center w-20 h-20 bg-gradient-to-br from-[#C5A059] to-[#D4AF37] rounded-2xl mb-6 shadow-lg shadow-[#C5A059]/20">
                    <span className="text-[#0B1B32] text-2xl font-bold">{item.step}</span>
                  </div>
                  <h4 className="text-white font-bold text-lg mb-2">{item.title}</h4>
                  <p className="text-white/50 text-sm">{item.desc}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </motion.div>

        {/* CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center"
        >
          <div className="bg-gradient-to-r from-[#C5A059]/10 via-[#C5A059]/5 to-[#C5A059]/10 border border-[#C5A059]/20 rounded-2xl p-10">
            <h3 className="text-2xl font-bold text-white mb-4">Ready to Get Started?</h3>
            <p className="text-white/60 mb-8 max-w-xl mx-auto">
              Let's discuss how we can help your business achieve compliance excellence and strategic growth.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a
                href="#contact"
                className="inline-flex items-center justify-center gap-2 bg-gradient-to-r from-[#C5A059] to-[#D4AF37] text-[#0B1B32] px-8 py-4 rounded-xl font-bold text-lg transition-all shadow-lg hover:shadow-[#C5A059]/30 hover:scale-105"
              >
                Schedule Consultation
                <ArrowRight className="w-5 h-5" />
              </a>
              <a
                href="#calculator"
                className="inline-flex items-center justify-center gap-2 border-2 border-[#C5A059]/50 text-[#C5A059] px-8 py-4 rounded-xl font-semibold text-lg hover:bg-[#C5A059]/10 transition-all"
              >
                Calculate Your Tax
              </a>
            </div>
          </div>
        </motion.div>
      </div>

      {/* Service Detail Modal */}
      <AnimatePresence>
        {selectedService && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm"
            onClick={() => setSelectedService(null)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="relative bg-[#0B1B32] border border-white/10 rounded-2xl max-w-3xl w-full max-h-[90vh] overflow-y-auto"
            >
              {/* Header Image */}
              <div className="relative h-48 overflow-hidden rounded-t-2xl">
                <img
                  src={selectedService.image}
                  alt={selectedService.title}
                  className="w-full h-full object-cover"
                />
                <div className={`absolute inset-0 bg-gradient-to-br ${selectedService.color} opacity-80`} />
                <div className="absolute inset-0 bg-[#0B1B32]/30" />
                
                <button
                  onClick={() => setSelectedService(null)}
                  className="absolute top-4 right-4 w-10 h-10 bg-black/50 backdrop-blur-sm rounded-full flex items-center justify-center text-white hover:bg-black/70 transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
                
                <div className="absolute bottom-0 left-0 right-0 p-6 bg-gradient-to-t from-[#0B1B32] to-transparent">
                  <div className={`inline-flex items-center gap-2 ${selectedService.bgColor} ${selectedService.borderColor} border rounded-full px-3 py-1 mb-3`}>
                    <span className={`${selectedService.textColor} text-xs font-bold tracking-wider`}>{selectedService.category}</span>
                  </div>
                  <h3 className="text-2xl font-bold text-white">{selectedService.title}</h3>
                </div>
              </div>

              {/* Content */}
              <div className="p-6">
                {/* Why Urgent */}
                <div className="bg-red-500/10 border border-red-500/30 rounded-xl p-4 mb-6">
                  <div className="flex items-start gap-3">
                    <AlertTriangle className="w-6 h-6 text-red-400 flex-shrink-0 mt-0.5" />
                    <div>
                      <h4 className="text-red-400 font-semibold mb-1">Why You Need This Now?</h4>
                      <p className="text-white/70 text-sm leading-relaxed">{selectedService.whyUrgent}</p>
                    </div>
                  </div>
                </div>

                {/* Business Problems */}
                <div className="mb-6">
                  <h4 className="text-white font-semibold mb-4 flex items-center gap-2">
                    <Clock className="w-5 h-5 text-[#C5A059]" />
                    Common Business Problems We Solve
                  </h4>
                  <div className="space-y-3">
                    {selectedService.problems.map((problem, index) => (
                      <div
                        key={index}
                        className="flex items-start gap-3 bg-white/5 border border-white/10 rounded-lg p-3"
                      >
                        <div className="w-6 h-6 bg-red-500/20 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                          <span className="text-red-400 text-xs font-bold">{index + 1}</span>
                        </div>
                        <p className="text-white/70 text-sm">{problem}</p>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Benefits */}
                <div className="mb-6">
                  <h4 className="text-white font-semibold mb-4 flex items-center gap-2">
                    <TrendingUp className="w-5 h-5 text-[#C5A059]" />
                    How We Help Your Business
                  </h4>
                  <div className="flex flex-wrap gap-2">
                    {selectedService.benefits.map((benefit) => (
                      <span
                        key={benefit}
                        className={`inline-flex items-center gap-1 ${selectedService.bgColor} ${selectedService.borderColor} border rounded-full px-3 py-1`}
                      >
                        <CheckCircle className={`w-3 h-3 ${selectedService.textColor}`} />
                        <span className={`${selectedService.textColor} text-xs font-medium`}>{benefit}</span>
                      </span>
                    ))}
                  </div>
                </div>

                {/* CTA */}
                <div className="flex flex-col sm:flex-row gap-3 pt-4 border-t border-white/10">
                  <a
                    href="#contact"
                    onClick={() => setSelectedService(null)}
                    className={`flex-1 inline-flex items-center justify-center gap-2 bg-gradient-to-r ${selectedService.color} text-white py-3 rounded-lg font-semibold transition-all hover:opacity-90`}
                  >
                    Get Expert Help Now
                    <ArrowRight className="w-4 h-4" />
                  </a>
                  <a
                    href="https://wa.me/919817178929"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex-1 inline-flex items-center justify-center gap-2 bg-[#25D366] text-white py-3 rounded-lg font-semibold transition-all hover:bg-[#20BD5A]"
                  >
                    WhatsApp Consultation
                  </a>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}