import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Calendar, Tag, Shield, ExternalLink } from 'lucide-react';

interface GovtUpdate {
  id: number;
  title: string;
  excerpt: string;
  category: string;
  source_url: string;
  source_name: string;
  notification_date: string;
  priority: number;
}

const categoryColors: Record<string, string> = {
  'Income Tax': 'bg-green-100 text-green-700 border-green-200',
  'GST': 'bg-blue-100 text-blue-700 border-blue-200',
  'MCA': 'bg-purple-100 text-purple-700 border-purple-200',
  'Startup India': 'bg-orange-100 text-orange-700 border-orange-200',
};

export default function Blog() {
  const [updates, setUpdates] = useState<GovtUpdate[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchUpdates = async () => {
      try {
        const res = await fetch('/api/fetch-updates');
        const data = await res.json();
        setUpdates(data);
      } catch (err) {
        console.error('Failed to fetch updates:', err);
      } finally {
        setLoading(false);
      }
    };
    fetchUpdates();
  }, []);

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-IN', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
    });
  };

  return (
    <section id="blog" className="relative py-24 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <div className="inline-flex items-center gap-2 bg-blue-100 border border-blue-200 rounded-full px-4 py-2 mb-4">
            <Tag className="w-4 h-4 text-blue-600" />
            <span className="text-blue-700 text-sm font-medium">Knowledge Hub</span>
          </div>
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Latest <span className="text-blue-600">Insights</span>
          </h2>
          <p className="text-gray-600 max-w-2xl mx-auto text-lg">
            Stay updated with official notifications from Income Tax, GST, and MCA portals.
          </p>
        </motion.div>

        {/* Official Sources Badge */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="flex flex-wrap justify-center gap-4 mb-12"
        >
          {[
            { name: 'Income Tax Department', color: 'green' },
            { name: 'GST Portal', color: 'blue' },
            { name: 'MCA Portal', color: 'purple' },
          ].map((source) => (
            <div
              key={source.name}
              className="flex items-center gap-2 bg-white border border-gray-200 rounded-full px-4 py-2"
            >
              <Shield className={`w-4 h-4 text-${source.color}-600`} />
              <span className="text-gray-700 text-xs font-medium">{source.name}</span>
            </div>
          ))}
        </motion.div>

        {/* Updates Grid */}
        {loading ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[1, 2, 3].map((i) => (
              <div key={i} className="bg-white rounded-xl p-6 animate-pulse border border-gray-200">
                <div className="h-4 bg-gray-200 rounded w-1/3 mb-4" />
                <div className="h-6 bg-gray-200 rounded w-full mb-2" />
                <div className="h-4 bg-gray-200 rounded w-2/3 mb-4" />
                <div className="h-20 bg-gray-200 rounded" />
              </div>
            ))}
          </div>
        ) : updates.length === 0 ? (
          <div className="text-center py-16">
            <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Tag className="w-8 h-8 text-gray-400" />
            </div>
            <p className="text-gray-500">No updates available at the moment.</p>
          </div>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {updates.map((update, index) => (
              <motion.article
                key={update.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="group bg-white border border-gray-200 rounded-xl overflow-hidden hover:border-blue-300 hover:shadow-lg transition-all"
              >
                <div className="p-6">
                  {/* Category & Date */}
                  <div className="flex items-center justify-between mb-4">
                    <span className={`px-3 py-1 rounded-full text-xs font-medium border ${categoryColors[update.category] || 'bg-gray-100 text-gray-700 border-gray-200'}`}>
                      {update.category}
                    </span>
                    <span className="text-gray-500 text-xs flex items-center gap-1">
                      <Calendar className="w-3 h-3" />
                      {formatDate(update.notification_date)}
                    </span>
                  </div>

                  {/* Title */}
                  <h3 className="text-gray-900 font-semibold text-lg mb-3 group-hover:text-blue-600 transition-colors line-clamp-2">
                    {update.title}
                  </h3>

                  {/* Excerpt */}
                  <p className="text-gray-600 text-sm mb-4 line-clamp-3">{update.excerpt}</p>

                  {/* Source Link */}
                  <div className="flex items-center justify-between pt-4 border-t border-gray-100">
                    <span className="text-gray-500 text-xs flex items-center gap-1">
                      <Shield className="w-3 h-3" />
                      {update.source_name}
                    </span>
                    <a
                      href={update.source_url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-blue-600 text-sm font-medium flex items-center gap-1 hover:underline"
                    >
                      View Official
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  </div>
                </div>
              </motion.article>
            ))}
          </div>
        )}
      </div>
    </section>
  );
}