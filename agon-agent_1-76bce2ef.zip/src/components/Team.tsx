import { motion } from 'framer-motion';
import { User, Award, Mail, Phone, Briefcase, CheckCircle } from 'lucide-react';

const founder = {
  name: 'CMA Arun Bishnoi',
  title: 'Founder & Principal',
  qualification: 'Cost & Management Accountant',
  bio: 'A qualified Cost & Management Accountant with extensive experience in statutory audits, taxation, and corporate advisory. Committed to delivering excellence and professional integrity in every engagement.',
  expertise: ['Statutory Audits', 'Tax Planning', 'Corporate Compliance', 'Startup Advisory'],
  email: 'cmafirmarun@gmail.com',
  phone: '+91 98171 78929',
};

export default function Team() {
  return (
    <section id="team" className="relative py-24 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-[#0B1B32] via-[#0f2239] to-[#0B1B32]" />
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_bottom_right,rgba(197,160,89,0.05),transparent_50%)]" />
      
      {/* Decorative Elements */}
      <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-[#C5A059]/30 to-transparent" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <div className="inline-flex items-center gap-2 bg-[#C5A059]/10 border border-[#C5A059]/30 rounded-full px-4 py-2 mb-4">
            <User className="w-4 h-4 text-[#C5A059]" />
            <span className="text-[#C5A059] text-sm font-medium">Our Leadership</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-4">
            Meet Our <span className="text-[#C5A059]">Founder</span>
          </h2>
          <p className="text-white/60 max-w-2xl mx-auto text-lg">
            Professional excellence driven by expertise and commitment to client success.
          </p>
        </motion.div>

        {/* Founder Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="max-w-3xl mx-auto"
        >
          <div className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl p-8 hover:border-[#C5A059]/30 transition-all">
            {/* Icon Avatar */}
            <div className="flex justify-center mb-6">
              <div className="w-24 h-24 bg-gradient-to-br from-[#C5A059] to-[#D4AF37] rounded-full flex items-center justify-center shadow-lg shadow-[#C5A059]/20">
                <User className="w-12 h-12 text-[#0B1B32]" />
              </div>
            </div>

            {/* Name & Title */}
            <div className="text-center mb-6">
              <h3 className="text-2xl font-bold text-white mb-1">{founder.name}</h3>
              <p className="text-[#C5A059] font-medium">{founder.title}</p>
              <p className="text-white/50 text-sm">{founder.qualification}</p>
            </div>

            {/* Bio */}
            <p className="text-white/60 mb-6 leading-relaxed text-center">{founder.bio}</p>

            {/* Expertise Tags */}
            <div className="mb-6">
              <p className="text-white/40 text-xs uppercase tracking-wider mb-3 text-center">Areas of Expertise</p>
              <div className="flex flex-wrap justify-center gap-2">
                {founder.expertise.map((skill) => (
                  <span
                    key={skill}
                    className="bg-[#C5A059]/10 border border-[#C5A059]/30 text-[#C5A059] px-3 py-1 rounded-full text-xs font-medium"
                  >
                    {skill}
                  </span>
                ))}
              </div>
            </div>

            {/* Contact */}
            <div className="flex flex-wrap justify-center gap-6 pt-6 border-t border-white/10">
              <a
                href={`mailto:${founder.email}`}
                className="flex items-center gap-2 text-white/60 hover:text-[#C5A059] transition-colors text-sm"
              >
                <Mail className="w-4 h-4" />
                {founder.email}
              </a>
              <a
                href={`tel:${founder.phone.replace(/\s/g, '')}`}
                className="flex items-center gap-2 text-white/60 hover:text-[#C5A059] transition-colors text-sm"
              >
                <Phone className="w-4 h-4" />
                {founder.phone}
              </a>
            </div>
          </div>
        </motion.div>

        {/* Firm Values */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 mt-16"
        >
          {[
            { icon: Award, title: 'Professional Integrity', desc: 'Highest ethical standards' },
            { icon: Briefcase, title: 'Technical Excellence', desc: 'Accurate solutions' },
            { icon: User, title: 'Client Partnership', desc: 'Personalized service' },
            { icon: CheckCircle, title: 'Value Creation', desc: 'Measurable results' },
          ].map((value, index) => (
            <motion.div
              key={value.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="text-center p-6 bg-white/5 rounded-xl border border-white/10 hover:border-[#C5A059]/30 transition-all"
            >
              <div className="w-12 h-12 bg-[#C5A059]/20 rounded-lg flex items-center justify-center mx-auto mb-4">
                <value.icon className="w-6 h-6 text-[#C5A059]" />
              </div>
              <h4 className="text-white font-semibold mb-1">{value.title}</h4>
              <p className="text-white/50 text-sm">{value.desc}</p>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}