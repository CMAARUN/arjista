import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Lock, RefreshCw, CheckCircle, XCircle, ExternalLink, Calendar, Tag, ArrowLeft, Mail, Phone, Building, MessageSquare, User, Users, FileText } from 'lucide-react';

interface GovtUpdate {
  id: number;
  title: string;
  excerpt: string;
  category: string;
  source_url: string;
  source_name: string;
  notification_date: string;
  priority: number;
}

interface ContactInquiry {
  id: number;
  name: string;
  email: string;
  phone: string;
  company: string;
  service_type: string;
  message: string;
  created_at: string;
}

interface PartnerInquiry {
  id: number;
  name: string;
  email: string;
  phone: string;
  qualification: string;
  experience_years: string;
  specialization: string;
  message: string;
  status: string;
  created_at: string;
}

type TabType = 'updates' | 'contacts' | 'partners';

export default function Admin() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [activeTab, setActiveTab] = useState<TabType>('contacts');
  
  const [updates, setUpdates] = useState<GovtUpdate[]>([]);
  const [contacts, setContacts] = useState<ContactInquiry[]>([]);
  const [partners, setPartners] = useState<PartnerInquiry[]>([]);
  
  const [fetching, setFetching] = useState(false);
  const [fetchResult, setFetchResult] = useState<{success: boolean; message: string} | null>(null);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      const res = await fetch('/api/admin-auth', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ password }),
      });

      const data = await res.json();
      
      if (data.success) {
        setIsLoggedIn(true);
        fetchAllData();
      } else {
        setError('Invalid password');
      }
    } catch (err) {
      setError('Login failed');
    } finally {
      setLoading(false);
    }
  };

  const fetchAllData = async () => {
    fetchContacts();
    fetchPartners();
    fetchUpdates();
  };

  const fetchContacts = async () => {
    try {
      const res = await fetch('/api/contact');
      const data = await res.json();
      setContacts(data);
    } catch (err) {
      console.error('Failed to fetch contacts:', err);
    }
  };

  const fetchPartners = async () => {
    try {
      const res = await fetch('/api/partner');
      const data = await res.json();
      setPartners(data);
    } catch (err) {
      console.error('Failed to fetch partners:', err);
    }
  };

  const fetchUpdates = async () => {
    try {
      const res = await fetch('/api/fetch-updates');
      const data = await res.json();
      setUpdates(data);
    } catch (err) {
      console.error('Failed to fetch updates:', err);
    }
  };

  const handleFetchLatest = async () => {
    setFetching(true);
    setFetchResult(null);

    try {
      const res = await fetch('/api/fetch-updates', { method: 'POST' });
      const data = await res.json();
      
      setFetchResult({
        success: data.success,
        message: data.message,
      });
      
      if (data.success) {
        fetchUpdates();
      }
    } catch (err) {
      setFetchResult({
        success: false,
        message: 'Failed to fetch updates',
      });
    } finally {
      setFetching(false);
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'Income Tax': return 'bg-green-500/20 text-green-400 border-green-500/30';
      case 'GST': return 'bg-blue-500/20 text-blue-400 border-blue-500/30';
      case 'MCA': return 'bg-purple-500/20 text-purple-400 border-purple-500/30';
      default: return 'bg-[#C5A059]/20 text-[#C5A059] border-[#C5A059]/30';
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-IN', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  if (!isLoggedIn) {
    return (
      <div className="min-h-screen bg-[#0B1B32] flex items-center justify-center p-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl p-8 w-full max-w-md"
        >
          <div className="text-center mb-8">
            <div className="w-16 h-16 bg-[#C5A059]/20 rounded-full flex items-center justify-center mx-auto mb-4">
              <Lock className="w-8 h-8 text-[#C5A059]" />
            </div>
            <h1 className="text-2xl font-bold text-white">Admin Panel</h1>
            <p className="text-white/50 text-sm mt-2">Arjista Services & Projects</p>
          </div>

          <form onSubmit={handleLogin}>
            <div className="mb-6">
              <label className="block text-white/60 text-sm mb-2">Password</label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full bg-[#0B1B32] border border-white/20 rounded-lg py-3 px-4 text-white placeholder-white/30 focus:outline-none focus:border-[#C5A059] transition-colors"
                placeholder="Enter admin password"
              />
            </div>

            {error && (
              <div className="mb-4 p-3 bg-red-500/10 border border-red-500/30 rounded-lg text-red-400 text-sm text-center">
                {error}
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-[#C5A059] hover:bg-[#D4AF37] text-[#0B1B32] py-3 rounded-lg font-semibold transition-all disabled:opacity-50"
            >
              {loading ? 'Logging in...' : 'Login'}
            </button>
          </form>

          <a
            href="/"
            className="flex items-center justify-center gap-2 text-white/50 hover:text-[#C5A059] text-sm mt-6 transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Website
          </a>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0B1B32]">
      {/* Header */}
      <header className="bg-[#0B1B32]/95 backdrop-blur-md border-b border-white/10 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-[#C5A059] to-[#D4AF37] rounded-lg flex items-center justify-center">
                <span className="text-[#0B1B32] font-bold text-lg">A</span>
              </div>
              <div>
                <span className="text-white font-semibold">Admin Panel</span>
                <span className="block text-[#C5A059] text-xs">Arjista Services</span>
              </div>
            </div>
            <a
              href="/"
              className="flex items-center gap-2 text-white/60 hover:text-[#C5A059] text-sm transition-colors"
            >
              <ArrowLeft className="w-4 h-4" />
              Back to Website
            </a>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <div className="bg-white/5 border border-white/10 rounded-xl p-4">
            <div className="text-2xl font-bold text-[#C5A059]">{contacts.length}</div>
            <div className="text-white/50 text-sm">Contact Inquiries</div>
          </div>
          <div className="bg-white/5 border border-white/10 rounded-xl p-4">
            <div className="text-2xl font-bold text-[#C5A059]">{partners.length}</div>
            <div className="text-white/50 text-sm">Partner Requests</div>
          </div>
          <div className="bg-white/5 border border-white/10 rounded-xl p-4">
            <div className="text-2xl font-bold text-[#C5A059]">{updates.length}</div>
            <div className="text-white/50 text-sm">Govt Updates</div>
          </div>
          <div className="bg-white/5 border border-white/10 rounded-xl p-4">
            <div className="text-2xl font-bold text-green-400">{partners.filter(p => p.status === 'pending').length}</div>
            <div className="text-white/50 text-sm">Pending Reviews</div>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex gap-2 mb-6 overflow-x-auto pb-2">
          {[
            { id: 'contacts' as TabType, label: 'Contact Inquiries', icon: Mail, count: contacts.length },
            { id: 'partners' as TabType, label: 'Partner Requests', icon: Users, count: partners.length },
            { id: 'updates' as TabType, label: 'Govt Updates', icon: FileText, count: updates.length },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium text-sm whitespace-nowrap transition-all ${
                activeTab === tab.id
                  ? 'bg-[#C5A059] text-[#0B1B32]'
                  : 'bg-white/5 text-white/60 hover:bg-white/10'
              }`}
            >
              <tab.icon className="w-4 h-4" />
              {tab.label}
              <span className={`px-2 py-0.5 rounded-full text-xs ${
                activeTab === tab.id ? 'bg-[#0B1B32]/20' : 'bg-white/10'
              }`}>
                {tab.count}
              </span>
            </button>
          ))}
        </div>

        {/* Contact Inquiries Tab */}
        {activeTab === 'contacts' && (
          <div className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl overflow-hidden">
            <div className="p-4 border-b border-white/10 flex items-center justify-between">
              <h3 className="text-white font-semibold">Contact Inquiries</h3>
              <button
                onClick={fetchContacts}
                className="p-2 hover:bg-white/10 rounded-lg transition-colors"
              >
                <RefreshCw className="w-4 h-4 text-white/60" />
              </button>
            </div>
            
            {contacts.length === 0 ? (
              <div className="p-8 text-center text-white/50">No inquiries yet</div>
            ) : (
              <div className="divide-y divide-white/10">
                {contacts.map((contact) => (
                  <div key={contact.id} className="p-4 hover:bg-white/5 transition-colors">
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <span className="bg-[#C5A059]/20 text-[#C5A059] px-2 py-0.5 rounded text-xs font-medium">
                            {contact.service_type}
                          </span>
                          <span className="text-white/40 text-xs">{formatDate(contact.created_at)}</span>
                        </div>
                        <h4 className="text-white font-medium mb-1">{contact.name}</h4>
                        <div className="space-y-1 text-sm">
                          <div className="flex items-center gap-2 text-white/60">
                            <Mail className="w-3 h-3" />
                            <a href={`mailto:${contact.email}`} className="hover:text-[#C5A059]">{contact.email}</a>
                          </div>
                          {contact.phone && (
                            <div className="flex items-center gap-2 text-white/60">
                              <Phone className="w-3 h-3" />
                              <a href={`tel:${contact.phone}`} className="hover:text-[#C5A059]">{contact.phone}</a>
                            </div>
                          )}
                          {contact.company && (
                            <div className="flex items-center gap-2 text-white/60">
                              <Building className="w-3 h-3" />
                              {contact.company}
                            </div>
                          )}
                        </div>
                        <p className="text-white/50 text-sm mt-2 line-clamp-2">{contact.message}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Partner Requests Tab */}
        {activeTab === 'partners' && (
          <div className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl overflow-hidden">
            <div className="p-4 border-b border-white/10 flex items-center justify-between">
              <h3 className="text-white font-semibold">Partner Requests</h3>
              <button
                onClick={fetchPartners}
                className="p-2 hover:bg-white/10 rounded-lg transition-colors"
              >
                <RefreshCw className="w-4 h-4 text-white/60" />
              </button>
            </div>
            
            {partners.length === 0 ? (
              <div className="p-8 text-center text-white/50">No partner requests yet</div>
            ) : (
              <div className="divide-y divide-white/10">
                {partners.map((partner) => (
                  <div key={partner.id} className="p-4 hover:bg-white/5 transition-colors">
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <span className={`px-2 py-0.5 rounded text-xs font-medium ${
                            partner.status === 'pending' 
                              ? 'bg-yellow-500/20 text-yellow-400' 
                              : partner.status === 'approved'
                              ? 'bg-green-500/20 text-green-400'
                              : 'bg-red-500/20 text-red-400'
                          }`}>
                            {partner.status}
                          </span>
                          <span className="text-white/40 text-xs">{formatDate(partner.created_at)}</span>
                        </div>
                        <h4 className="text-white font-medium mb-1">{partner.name}</h4>
                        <div className="space-y-1 text-sm">
                          <div className="flex items-center gap-2 text-white/60">
                            <User className="w-3 h-3" />
                            {partner.qualification} • {partner.experience_years} experience
                          </div>
                          <div className="flex items-center gap-2 text-white/60">
                            <Mail className="w-3 h-3" />
                            <a href={`mailto:${partner.email}`} className="hover:text-[#C5A059]">{partner.email}</a>
                          </div>
                          {partner.phone && (
                            <div className="flex items-center gap-2 text-white/60">
                              <Phone className="w-3 h-3" />
                              <a href={`tel:${partner.phone}`} className="hover:text-[#C5A059]">{partner.phone}</a>
                            </div>
                          )}
                          {partner.specialization && (
                            <div className="text-white/50">Specialization: {partner.specialization}</div>
                          )}
                        </div>
                        {partner.message && (
                          <p className="text-white/50 text-sm mt-2 line-clamp-2">{partner.message}</p>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Govt Updates Tab */}
        {activeTab === 'updates' && (
          <div className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl overflow-hidden">
            <div className="p-4 border-b border-white/10 flex items-center justify-between">
              <h3 className="text-white font-semibold">Government Updates</h3>
              <button
                onClick={handleFetchLatest}
                disabled={fetching}
                className="flex items-center gap-2 bg-[#C5A059] hover:bg-[#D4AF37] text-[#0B1B32] px-4 py-2 rounded-lg font-medium text-sm transition-all disabled:opacity-50"
              >
                <RefreshCw className={`w-4 h-4 ${fetching ? 'animate-spin' : ''}`} />
                Fetch Latest
              </button>
            </div>

            {fetchResult && (
              <div className={`p-4 flex items-center gap-2 ${
                fetchResult.success ? 'bg-green-500/10 text-green-400' : 'bg-red-500/10 text-red-400'
              }`}>
                {fetchResult.success ? <CheckCircle className="w-4 h-4" /> : <XCircle className="w-4 h-4" />}
                {fetchResult.message}
              </div>
            )}
            
            {updates.length === 0 ? (
              <div className="p-8 text-center text-white/50">No updates yet. Click "Fetch Latest" to get updates.</div>
            ) : (
              <div className="divide-y divide-white/10">
                {updates.map((update) => (
                  <div key={update.id} className="p-4 hover:bg-white/5 transition-colors">
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <span className={`px-2 py-0.5 rounded text-xs font-medium border ${getCategoryColor(update.category)}`}>
                            {update.category}
                          </span>
                          <span className="text-white/40 text-xs">{update.notification_date}</span>
                        </div>
                        <h4 className="text-white font-medium mb-1">{update.title}</h4>
                        <p className="text-white/50 text-sm">{update.excerpt}</p>
                        <a
                          href={update.source_url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-[#C5A059] text-xs hover:underline flex items-center gap-1 mt-2"
                        >
                          {update.source_name}
                          <ExternalLink className="w-3 h-3" />
                        </a>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </main>
    </div>
  );
}