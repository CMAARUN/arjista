import { useState } from 'react';
import { motion } from 'framer-motion';
import { Handshake, Send, CheckCircle, User } from 'lucide-react';

const qualifications = [
  'Chartered Accountant (CA)',
  'Cost & Management Accountant (CMA)',
  'Company Secretary (CS)',
  'CA + CMA',
  'CA + CS',
  'CMA + CS',
  'CA + CMA + CS',
  'Other Professional Qualification',
];

export default function Partner() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    qualification: '',
    experience_years: '',
    specialization: '',
    message: '',
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      const res = await fetch('/api/partner', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });

      if (res.ok) {
        setIsSubmitted(true);
        setFormData({
          name: '',
          email: '',
          phone: '',
          qualification: '',
          experience_years: '',
          specialization: '',
          message: '',
        });
      }
    } catch (err) {
      console.error('Submit error:', err);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <section id="partner" className="relative py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Compact Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-10"
        >
          <div className="inline-flex items-center gap-2 bg-blue-100 border border-blue-200 rounded-full px-4 py-1.5 mb-4">
            <Handshake className="w-4 h-4 text-blue-600" />
            <span className="text-blue-700 text-xs font-semibold tracking-wide">Partner With Us</span>
          </div>
          
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-3">
            Open for <span className="text-blue-600">Collaboration</span>
          </h2>
          
          <p className="text-gray-600 max-w-2xl mx-auto text-lg">
            I am open to partnering with anyone who is ready to collaborate and grow together. 
            CA, CMA, CS professionals are welcome to connect.
          </p>
        </motion.div>

        {/* Two Column Layout */}
        <div className="grid lg:grid-cols-2 gap-8 items-start">
          {/* Left - Highlight Card */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="bg-blue-50 border border-blue-200 rounded-xl p-6"
          >
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 bg-blue-600 rounded-lg flex items-center justify-center shadow-lg shadow-blue-600/30">
                <Handshake className="w-6 h-6 text-white" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-gray-900">Partnership Opportunities</h3>
                <p className="text-blue-600 text-xs">Grow Together</p>
              </div>
            </div>
            
            <p className="text-gray-700 text-sm leading-relaxed mb-4">
              "I believe in the power of collaboration. Whether you're a fellow professional or a firm 
              looking to expand capabilities, I welcome the opportunity to work together."
            </p>

            <div className="grid grid-cols-2 gap-3">
              {[
                { title: 'CA Firms', desc: 'Joint engagements' },
                { title: 'CMA Professionals', desc: 'Cost advisory' },
                { title: 'CS Firms', desc: 'Corporate law' },
                { title: 'Legal Experts', desc: 'Litigation support' },
              ].map((item) => (
                <div key={item.title} className="bg-white rounded-lg p-3 border border-gray-200">
                  <p className="text-gray-900 text-sm font-medium">{item.title}</p>
                  <p className="text-gray-500 text-xs">{item.desc}</p>
                </div>
              ))}
            </div>
          </motion.div>

          {/* Right - Partner Inquiry Form */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            {isSubmitted ? (
              <div className="bg-gray-50 border border-gray-200 rounded-xl p-8 text-center">
                <div className="w-14 h-14 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <CheckCircle className="w-7 h-7 text-blue-600" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-2">Thank You!</h3>
                <p className="text-gray-600 text-sm mb-4">
                  Your partnership inquiry has been received. We will review your profile and get back to you soon.
                </p>
                <button
                  onClick={() => setIsSubmitted(false)}
                  className="text-blue-600 text-sm hover:underline font-medium"
                >
                  Submit another inquiry
                </button>
              </div>
            ) : (
              <div className="bg-gray-50 border border-gray-200 rounded-xl p-6">
                <h3 className="text-lg font-bold text-gray-900 mb-4 flex items-center gap-2">
                  <User className="w-5 h-5 text-blue-600" />
                  Partner Inquiry Form
                </h3>
                <p className="text-gray-500 text-xs mb-4">
                  Open for CA, CMA, CS professionals. Submit your details and we'll evaluate your partnership request.
                </p>

                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="grid sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-gray-700 text-xs font-medium mb-1">Full Name *</label>
                      <input
                        type="text"
                        required
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        className="w-full bg-white border border-gray-300 rounded-lg py-2.5 px-3 text-gray-900 text-sm placeholder-gray-400 focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 transition-all"
                        placeholder="Your name"
                      />
                    </div>
                    <div>
                      <label className="block text-gray-700 text-xs font-medium mb-1">Email *</label>
                      <input
                        type="email"
                        required
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        className="w-full bg-white border border-gray-300 rounded-lg py-2.5 px-3 text-gray-900 text-sm placeholder-gray-400 focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 transition-all"
                        placeholder="your@email.com"
                      />
                    </div>
                  </div>

                  <div className="grid sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-gray-700 text-xs font-medium mb-1">Phone</label>
                      <input
                        type="tel"
                        value={formData.phone}
                        onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                        className="w-full bg-white border border-gray-300 rounded-lg py-2.5 px-3 text-gray-900 text-sm placeholder-gray-400 focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 transition-all"
                        placeholder="+91 XXXXX XXXXX"
                      />
                    </div>
                    <div>
                      <label className="block text-gray-700 text-xs font-medium mb-1">Qualification *</label>
                      <select
                        required
                        value={formData.qualification}
                        onChange={(e) => setFormData({ ...formData, qualification: e.target.value })}
                        className="w-full bg-white border border-gray-300 rounded-lg py-2.5 px-3 text-gray-900 text-sm focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 transition-all"
                      >
                        <option value="" className="bg-white">Select qualification</option>
                        {qualifications.map((q) => (
                          <option key={q} value={q} className="bg-white">{q}</option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div className="grid sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-gray-700 text-xs font-medium mb-1">Experience (Years)</label>
                      <input
                        type="text"
                        value={formData.experience_years}
                        onChange={(e) => setFormData({ ...formData, experience_years: e.target.value })}
                        className="w-full bg-white border border-gray-300 rounded-lg py-2.5 px-3 text-gray-900 text-sm placeholder-gray-400 focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 transition-all"
                        placeholder="e.g., 5+ years"
                      />
                    </div>
                    <div>
                      <label className="block text-gray-700 text-xs font-medium mb-1">Specialization</label>
                      <input
                        type="text"
                        value={formData.specialization}
                        onChange={(e) => setFormData({ ...formData, specialization: e.target.value })}
                        className="w-full bg-white border border-gray-300 rounded-lg py-2.5 px-3 text-gray-900 text-sm placeholder-gray-400 focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 transition-all"
                        placeholder="e.g., Taxation, Audit"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-gray-700 text-xs font-medium mb-1">Message</label>
                    <textarea
                      rows={3}
                      value={formData.message}
                      onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                      className="w-full bg-white border border-gray-300 rounded-lg py-2.5 px-3 text-gray-900 text-sm placeholder-gray-400 focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 transition-all resize-none"
                      placeholder="Tell us about yourself and why you want to partner..."
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 rounded-lg font-semibold text-sm transition-all shadow-lg hover:shadow-blue-600/30 flex items-center justify-center gap-2 disabled:opacity-50"
                  >
                    {isSubmitting ? (
                      <span className="flex items-center gap-2">
                        <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                        Submitting...
                      </span>
                    ) : (
                      <>
                        <Send className="w-4 h-4" />
                        Submit Partnership Request
                      </>
                    )}
                  </button>
                </form>
              </div>
            )}
          </motion.div>
        </div>
      </div>
    </section>
  );
}