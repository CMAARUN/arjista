import { useState, useEffect } from 'react';
import { Bell, X } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

interface Notification {
  id: number;
  title: string;
  category: string;
  priority: number;
}

export default function NotificationTicker() {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isVisible, setIsVisible] = useState(true);

  useEffect(() => {
    const fetchNotifications = async () => {
      try {
        const res = await fetch('/api/notifications');
        const data = await res.json();
        setNotifications(data);
      } catch (err) {
        console.error('Failed to fetch notifications:', err);
      }
    };
    fetchNotifications();
  }, []);

  useEffect(() => {
    if (notifications.length === 0) return;
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % notifications.length);
    }, 6000);
    return () => clearInterval(interval);
  }, [notifications.length]);

  if (!isVisible || notifications.length === 0) return null;

  const current = notifications[currentIndex];

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'GST':
        return 'bg-blue-100 text-blue-700 border-blue-200';
      case 'Income Tax':
        return 'bg-green-100 text-green-700 border-green-200';
      case 'MCA':
        return 'bg-purple-100 text-purple-700 border-purple-200';
      default:
        return 'bg-blue-100 text-blue-700 border-blue-200';
    }
  };

  return (
    <div className="fixed top-20 left-0 right-0 z-40 bg-white/95 backdrop-blur-sm border-b border-gray-200 py-2.5 px-4 shadow-sm">
      <div className="max-w-7xl mx-auto flex items-center gap-4">
        {/* Bell Icon */}
        <div className="flex items-center gap-2 flex-shrink-0">
          <div className="w-7 h-7 bg-blue-100 rounded-full flex items-center justify-center">
            <Bell className="w-3.5 h-3.5 text-blue-600" />
          </div>
          <span className="text-gray-600 text-xs font-medium uppercase tracking-wider hidden sm:block">Alerts</span>
        </div>

        {/* Ticker Content */}
        <div className="overflow-hidden flex-1">
          <AnimatePresence mode="wait">
            <motion.div
              key={current.id}
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: -20, opacity: 0 }}
              transition={{ duration: 0.4 }}
              className="flex items-center gap-3"
            >
              <span className={`px-2.5 py-1 rounded text-xs font-semibold uppercase tracking-wide border ${getCategoryColor(current.category)}`}>
                {current.category}
              </span>
              <span className="text-gray-700 text-sm font-medium truncate">{current.title}</span>
            </motion.div>
          </AnimatePresence>
        </div>

        {/* Navigation & Close */}
        <div className="flex items-center gap-2 flex-shrink-0">
          <span className="text-gray-400 text-xs">
            {currentIndex + 1}/{notifications.length}
          </span>
          <button
            onClick={() => setIsVisible(false)}
            className="p-1.5 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <X className="w-4 h-4 text-gray-400" />
          </button>
        </div>
      </div>
    </div>
  );
}