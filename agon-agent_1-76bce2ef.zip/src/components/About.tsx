import { motion } from 'framer-motion';
import { Award, Users, Target, Lightbulb, CheckCircle, User, Briefcase } from 'lucide-react';

const values = [
  {
    icon: Award,
    title: 'Professional Integrity',
    desc: 'Upholding the highest ethical standards in all professional engagements.',
  },
  {
    icon: Target,
    title: 'Technical Excellence',
    desc: 'Delivering accurate, thorough, and technically sound solutions.',
  },
  {
    icon: Users,
    title: 'Client Partnership',
    desc: 'Building lasting relationships through personalized service delivery.',
  },
  {
    icon: Lightbulb,
    title: 'Forward Thinking',
    desc: 'Leveraging technology and modern practices for superior outcomes.',
  },
];

const whyChooseUs = [
  'Qualified Cost & Management Accountants with deep domain expertise',
  'Proven track record serving listed entities and multinational corporations',
  'Comprehensive service portfolio under one professional roof',
  'Technology-enabled compliance and reporting frameworks',
  'Dedicated engagement managers for each client relationship',
  'Transparent engagement terms with value-driven pricing',
];

export default function About() {
  return (
    <section id="about" className="relative py-24 overflow-hidden">
      {/* Background Image with Overlay */}
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{ backgroundImage: 'url(/images/office-main.jpg)' }}
      />
      <div className="absolute inset-0 bg-gradient-to-br from-[#0B1B32] via-[#0B1B32]/95 to-[#0B1B32]/90" />
      
      {/* Decorative Elements */}
      <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-[#C5A059]/30 to-transparent" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Left Column */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <div className="inline-flex items-center gap-2 bg-[#C5A059]/10 border border-[#C5A059]/30 rounded-full px-4 py-2 mb-4">
              <Briefcase className="w-4 h-4 text-[#C5A059]" />
              <span className="text-[#C5A059] text-sm font-medium">About The Firm</span>
            </div>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mt-2 mb-6 leading-tight">
              Your Trusted Partner for
              <span className="block text-[#C5A059]">Professional Excellence</span>
            </h2>
            <p className="text-white/60 mb-6 leading-relaxed text-lg">
              Arjista Services & Projects is a boutique professional services firm founded on the principles 
              of technical excellence, professional integrity, and client success. Our team brings together 
              expertise from leading professional backgrounds, delivering world-class services to businesses 
              and individuals across India.
            </p>
            <p className="text-white/60 mb-8 leading-relaxed">
              Whether you are a startup navigating regulatory requirements, a multinational corporation seeking 
              comprehensive compliance solutions, or a high-net-worth individual looking for strategic tax planning, 
              we possess the expertise to guide you through every professional challenge.
            </p>

            {/* Founder Section */}
            <div className="bg-gradient-to-r from-[#C5A059]/10 to-transparent border-l-4 border-[#C5A059] p-6 rounded-r-xl mb-8">
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 bg-gradient-to-br from-[#C5A059] to-[#D4AF37] rounded-full flex items-center justify-center flex-shrink-0 shadow-lg shadow-[#C5A059]/20">
                  <User className="w-8 h-8 text-[#0B1B32]" />
                </div>
                <div>
                  <p className="text-[#C5A059] text-xs uppercase tracking-widest font-medium mb-1">Founder & Principal</p>
                  <h3 className="text-white text-xl font-bold">CMA Arun Bishnoi</h3>
                  <p className="text-white/50 text-sm">Cost & Management Accountant</p>
                </div>
              </div>
            </div>

            {/* Why Choose Us */}
            <div className="space-y-3">
              {whyChooseUs.map((item, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                  className="flex items-center gap-3"
                >
                  <CheckCircle className="w-5 h-5 text-[#C5A059] flex-shrink-0" />
                  <span className="text-white/70">{item}</span>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Right Column - Values Grid */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="grid sm:grid-cols-2 gap-6"
          >
            {values.map((value, index) => (
              <motion.div
                key={value.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="group bg-white/5 backdrop-blur-sm border border-white/10 rounded-xl p-6 hover:bg-white/10 hover:border-[#C5A059]/30 transition-all"
              >
                <div className="w-12 h-12 bg-gradient-to-br from-[#C5A059] to-[#D4AF37] rounded-lg flex items-center justify-center mb-4 shadow-lg shadow-[#C5A059]/20 group-hover:scale-110 transition-transform">
                  <value.icon className="w-6 h-6 text-[#0B1B32]" />
                </div>
                <h3 className="text-white font-semibold text-lg mb-2">{value.title}</h3>
                <p className="text-white/50 text-sm leading-relaxed">{value.desc}</p>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </div>
    </section>
  );
}