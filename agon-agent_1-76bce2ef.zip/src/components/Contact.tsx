import { useState } from 'react';
import { motion } from 'framer-motion';
import { MapPin, Phone, Mail, Clock, Send, CheckCircle, MessageCircle, HeadphonesIcon } from 'lucide-react';

const contactInfo = [
  {
    icon: MapPin,
    title: 'Registered Office',
    value: 'TF-9/330, Gali No. 9, Lalita Park, Laxmi Nagar, Delhi-110092',
  },
  {
    icon: Phone,
    title: 'Telephone',
    value: '+91 98171 78929 | +91 87089 71502',
    href: 'tel:+919817178929',
  },
  {
    icon: Mail,
    title: 'Email',
    value: 'cmafirmarun@gmail.com',
    href: 'mailto:cmafirmarun@gmail.com',
  },
  {
    icon: Clock,
    title: 'Business Hours',
    value: 'Monday - Saturday: 10:00 AM - 7:00 PM',
  },
];

const serviceTypes = [
  'Statutory Audit',
  'Tax Compliance',
  'GST Advisory',
  'Virtual CFO',
  'Startup Advisory',
  'Litigation Support',
  'Wealth Management',
  'Other',
];

export default function Contact() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    company: '',
    service_type: '',
    message: '',
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      const res = await fetch('/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });

      if (res.ok) {
        setIsSubmitted(true);
        setFormData({
          name: '',
          email: '',
          phone: '',
          company: '',
          service_type: '',
          message: '',
        });
      }
    } catch (err) {
      console.error('Submit error:', err);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleWhatsApp = () => {
    const message = encodeURIComponent('Hello, I would like to inquire about your professional services.');
    window.open(`https://wa.me/919817178929?text=${message}`, '_blank');
  };

  return (
    <section id="contact" className="relative py-24 overflow-hidden bg-gray-900">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_bottom_left,rgba(59,130,246,0.05),transparent_50%)]" />
      
      {/* Decorative Elements */}
      <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-blue-500/30 to-transparent" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <div className="inline-flex items-center gap-2 bg-blue-500/10 border border-blue-500/30 rounded-full px-4 py-2 mb-4">
            <HeadphonesIcon className="w-4 h-4 text-blue-400" />
            <span className="text-blue-400 text-sm font-medium">Get In Touch</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-4">
            Schedule a <span className="text-blue-400">Consultation</span>
          </h2>
          <p className="text-gray-400 max-w-2xl mx-auto text-lg">
            Ready to streamline your compliance framework and optimize your tax strategy? 
            Connect with our professional team for a personalized consultation.
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-5 gap-12">
          {/* Contact Info */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="lg:col-span-2 space-y-4"
          >
            {contactInfo.map((info, index) => (
              <motion.div
                key={info.title}
                initial={{ opacity: 0, y: 10 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="flex items-start gap-4 p-5 rounded-xl bg-gray-800/50 border border-gray-700 hover:border-blue-500/30 transition-all"
              >
                <div className="w-11 h-11 bg-blue-500/10 rounded-lg flex items-center justify-center flex-shrink-0">
                  <info.icon className="w-5 h-5 text-blue-400" />
                </div>
                <div>
                  <h4 className="text-white font-medium mb-1">{info.title}</h4>
                  {info.href ? (
                    <a href={info.href} className="text-gray-400 text-sm hover:text-blue-400 transition-colors">
                      {info.value}
                    </a>
                  ) : (
                    <p className="text-gray-400 text-sm">{info.value}</p>
                  )}
                </div>
              </motion.div>
            ))}

            {/* WhatsApp Button */}
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.5 }}
              className="pt-4"
            >
              <button
                onClick={handleWhatsApp}
                className="w-full flex items-center justify-center gap-3 bg-green-500 hover:bg-green-600 text-white py-4 rounded-xl font-semibold transition-all shadow-lg hover:shadow-green-500/30"
              >
                <MessageCircle className="w-6 h-6" />
                <span>Connect on WhatsApp</span>
              </button>
              <p className="text-gray-500 text-xs text-center mt-2">Direct message to +91 98171 78929</p>
            </motion.div>
          </motion.div>

          {/* Contact Form */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="lg:col-span-3"
          >
            {isSubmitted ? (
              <div className="bg-gray-800/50 border border-blue-500/30 rounded-2xl p-12 text-center">
                <div className="w-16 h-16 bg-blue-500/20 rounded-full flex items-center justify-center mx-auto mb-6">
                  <CheckCircle className="w-8 h-8 text-blue-400" />
                </div>
                <h3 className="text-2xl font-bold text-white mb-4">Inquiry Received</h3>
                <p className="text-gray-400 mb-6">
                  Thank you for your interest. CMA Arun Bishnoi will personally review your inquiry 
                  and respond within 24 business hours.
                </p>
                <div className="flex flex-col sm:flex-row gap-4 justify-center">
                  <button
                    onClick={() => setIsSubmitted(false)}
                    className="text-blue-400 hover:underline"
                  >
                    Submit another inquiry
                  </button>
                  <button
                    onClick={handleWhatsApp}
                    className="flex items-center justify-center gap-2 text-green-400 hover:underline"
                  >
                    <MessageCircle className="w-4 h-4" />
                    Connect on WhatsApp
                  </button>
                </div>
              </div>
            ) : (
              <form
                onSubmit={handleSubmit}
                className="bg-gray-800/50 border border-gray-700 rounded-2xl p-8 shadow-2xl"
              >
                <div className="grid sm:grid-cols-2 gap-6 mb-6">
                  <div>
                    <label className="block text-gray-400 text-sm mb-2">Full Name *</label>
                    <input
                      type="text"
                      required
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className="w-full bg-gray-900/50 border border-gray-600 rounded-lg py-3 px-4 text-white placeholder-gray-500 focus:outline-none focus:border-blue-500 transition-colors"
                      placeholder="Your full name"
                    />
                  </div>
                  <div>
                    <label className="block text-gray-400 text-sm mb-2">Email Address *</label>
                    <input
                      type="email"
                      required
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      className="w-full bg-gray-900/50 border border-gray-600 rounded-lg py-3 px-4 text-white placeholder-gray-500 focus:outline-none focus:border-blue-500 transition-colors"
                      placeholder="your@email.com"
                    />
                  </div>
                  <div>
                    <label className="block text-gray-400 text-sm mb-2">Phone Number</label>
                    <input
                      type="tel"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      className="w-full bg-gray-900/50 border border-gray-600 rounded-lg py-3 px-4 text-white placeholder-gray-500 focus:outline-none focus:border-blue-500 transition-colors"
                      placeholder="+91 XXXXX XXXXX"
                    />
                  </div>
                  <div>
                    <label className="block text-gray-400 text-sm mb-2">Company / Organization</label>
                    <input
                      type="text"
                      value={formData.company}
                      onChange={(e) => setFormData({ ...formData, company: e.target.value })}
                      className="w-full bg-gray-900/50 border border-gray-600 rounded-lg py-3 px-4 text-white placeholder-gray-500 focus:outline-none focus:border-blue-500 transition-colors"
                      placeholder="Company name"
                    />
                  </div>
                </div>

                <div className="mb-6">
                  <label className="block text-gray-400 text-sm mb-2">Service Required *</label>
                  <select
                    required
                    value={formData.service_type}
                    onChange={(e) => setFormData({ ...formData, service_type: e.target.value })}
                    className="w-full bg-gray-900/50 border border-gray-600 rounded-lg py-3 px-4 text-white focus:outline-none focus:border-blue-500 transition-colors"
                  >
                    <option value="" className="bg-gray-900">Select a service</option>
                    {serviceTypes.map((service) => (
                      <option key={service} value={service} className="bg-gray-900">
                        {service}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="mb-6">
                  <label className="block text-gray-400 text-sm mb-2">Your Requirements *</label>
                  <textarea
                    required
                    rows={4}
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    className="w-full bg-gray-900/50 border border-gray-600 rounded-lg py-3 px-4 text-white placeholder-gray-500 focus:outline-none focus:border-blue-500 transition-colors resize-none"
                    placeholder="Please describe your requirements or query..."
                  />
                </div>

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full bg-blue-600 hover:bg-blue-700 text-white py-4 rounded-lg font-semibold text-lg transition-all shadow-lg hover:shadow-blue-500/30 flex items-center justify-center gap-2 disabled:opacity-50"
                >
                  {isSubmitting ? (
                    <span className="flex items-center gap-2">
                      <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                      Sending...
                    </span>
                  ) : (
                    <>
                      <Send className="w-5 h-5" />
                      Submit Inquiry
                    </>
                  )}
                </button>
              </form>
            )}
          </motion.div>
        </div>
      </div>
    </section>
  );
}