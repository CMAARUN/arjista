import supabase from './_supabase.js';

const ADMIN_PASSWORD = 'Arjista@2025'; // Change this to your desired password

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'POST') {
      const { password } = req.body;
      
      if (password === ADMIN_PASSWORD) {
        return res.status(200).json({ 
          success: true, 
          token: Buffer.from(`admin:${Date.now()}`).toString('base64')
        });
      }
      
      return res.status(401).json({ success: false, error: 'Invalid password' });
    }

    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('API error:', err);
    res.status(500).json({ error: err.message });
  }
}