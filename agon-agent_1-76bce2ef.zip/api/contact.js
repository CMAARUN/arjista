import supabase from './_supabase.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const { data, error } = await supabase
        .from('contact_inquiries')
        .select('*')
        .order('created_at', { ascending: false });
      if (error) throw error;
      return res.status(200).json(data);
    }

    if (req.method === 'POST') {
      const { name, email, phone, company, service_type, message } = req.body;
      
      // Save to database
      const { data, error } = await supabase
        .from('contact_inquiries')
        .insert({ name, email, phone, company, service_type, message })
        .select()
        .single();
      
      if (error) throw error;

      // Send email notification
      try {
        const emailResponse = await fetch('https://api.resend.com/emails', {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${process.env.RESEND_API_KEY}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            from: 'Arjista Services <noreply@arjista.com>',
            to: 'cmafirmarun@gmail.com',
            subject: `New Inquiry from ${name} - ${service_type}`,
            html: `
              <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; background: #0B1B32; border-radius: 10px;">
                <div style="text-align: center; margin-bottom: 30px;">
                  <h1 style="color: #C5A059; margin: 0;">ARJISTA Services & Projects</h1>
                  <p style="color: #888; font-size: 14px;">New Client Inquiry</p>
                </div>
                
                <div style="background: #0f2239; padding: 20px; border-radius: 8px; margin-bottom: 20px;">
                  <h2 style="color: #C5A059; margin-top: 0;">Contact Details</h2>
                  <table style="width: 100%; color: #fff;">
                    <tr>
                      <td style="padding: 8px 0; color: #888;">Name:</td>
                      <td style="padding: 8px 0; color: #fff; font-weight: bold;">${name}</td>
                    </tr>
                    <tr>
                      <td style="padding: 8px 0; color: #888;">Email:</td>
                      <td style="padding: 8px 0;"><a href="mailto:${email}" style="color: #C5A059;">${email}</a></td>
                    </tr>
                    <tr>
                      <td style="padding: 8px 0; color: #888;">Phone:</td>
                      <td style="padding: 8px 0;"><a href="tel:${phone}" style="color: #C5A059;">${phone || 'Not provided'}</a></td>
                    </tr>
                    <tr>
                      <td style="padding: 8px 0; color: #888;">Company:</td>
                      <td style="padding: 8px 0; color: #fff;">${company || 'Not provided'}</td>
                    </tr>
                    <tr>
                      <td style="padding: 8px 0; color: #888;">Service:</td>
                      <td style="padding: 8px 0; color: #C5A059; font-weight: bold;">${service_type}</td>
                    </tr>
                  </table>
                </div>
                
                <div style="background: #0f2239; padding: 20px; border-radius: 8px; margin-bottom: 20px;">
                  <h3 style="color: #C5A059; margin-top: 0;">Message</h3>
                  <p style="color: #fff; line-height: 1.6; white-space: pre-wrap;">${message}</p>
                </div>
                
                <div style="text-align: center; margin-top: 30px;">
                  <a href="https://cmaarunbishnoi.vercel.app/admin" style="background: #C5A059; color: #0B1B32; padding: 12px 30px; text-decoration: none; border-radius: 6px; font-weight: bold;">View in Admin Panel</a>
                </div>
                
                <p style="color: #666; font-size: 12px; text-align: center; margin-top: 30px;">
                  This email was sent from your website contact form.
                </p>
              </div>
            `,
          }),
        });
        
        console.log('Email notification sent');
      } catch (emailError) {
        console.error('Email notification failed:', emailError);
        // Don't fail the request if email fails
      }

      return res.status(201).json(data);
    }

    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('API error:', err);
    res.status(500).json({ error: err.message });
  }
}